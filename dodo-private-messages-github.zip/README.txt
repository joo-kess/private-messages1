# Dodo Private Messages — GitHub Pages starter

## Files
- `index.html`: public send-a-message page
- `inbox.html`: password-protected inbox UI
- `config.js`: public Supabase URL and anon/publishable key placeholders

## Before publishing
1. In `config.js`, replace the two placeholders with your Supabase project URL and public anon/publishable key. Do NOT use a `service_role` or secret key.
2. These pages call the Edge Function named `super-worker`. If your function has a different name, update both HTML files.
3. The deployed Edge Function must have the `INBOX_PASSWORD` secret and the code must use the `private_messages` table.
4. The current sample Edge Function needs rate limiting / abuse protection before public launch. As written, anyone with the send link can send messages, and the inbox password check is vulnerable to repeated guesses. Do not treat it as production-secure until those protections are implemented.
5. The inbox password is sent to the Edge Function over HTTPS on each request. Use a strong unique password and never commit it to GitHub.
6. Do not put secret/service-role keys in these files.

## Publish to GitHub Pages
Upload all three files (`index.html`, `inbox.html`, `config.js`) to the root of your new repository. In GitHub, open Settings → Pages, select Deploy from a branch, choose `main` and `/ (root)`, and save. The public page will be the repository's Pages URL; the inbox is the same URL plus `/inbox.html`.

## Important
This is a starter UI, not a completed security review. Add server-side rate limiting, abuse controls, and test wrong-password / direct-database access before sharing the public link.
